local red = 0
local green = 0
local blue = 0

while (appRunning()) do
	red = red + 1;
end