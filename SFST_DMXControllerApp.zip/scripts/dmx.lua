DMX.setColor = function(channel, color)
end

DMX.setBrightness = function(brightness)
end