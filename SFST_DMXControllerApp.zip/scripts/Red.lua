wait(20)

DMX_setColor(255, 255, 255)
wait(0.25)
DMX_setColor(0, 0, 0)

wait(5)
DMX_setColor(255, 0, 0)